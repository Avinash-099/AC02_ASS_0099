#include <stdio.h>
int main() {
    int n;
    printf("Enter a decimal number: ");
    scanf("%d", &n);
    printf("Hexadecimal: %X\n", n);
    return 0;
}
